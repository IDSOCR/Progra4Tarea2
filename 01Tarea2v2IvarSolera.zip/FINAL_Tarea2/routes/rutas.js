const express = require('express');
const router = express.Router();

// Ruta principal "/"
router.get('/', (req, res) => {
    res.json({ mensaje: "¡Bienvenido a la API de Express!" });
});

// Ruta "/saludo" usando un controlador
const saludoController = require('../controllers/saludoController');
router.get('/saludo', saludoController.saludar);

module.exports = router;



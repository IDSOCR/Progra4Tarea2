// Importamos Express
const express = require('express');

// Creamos una instancia de Express
const app = express();

// Definimos el puerto donde correrá el servidor
const PORT = 3000;

// Ruta para la página de inicio "/"
app.get('/', (req, res) => {
    res.json({ mensaje: "¡Bienvenido compañeros y profesor a nuestro servidor Express!" });
});

// Iniciamos el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

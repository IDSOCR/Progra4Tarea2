// Importamos Express
const express = require('express');

// Creamos la instancia de Express
const app = express();

// Middleware para registrar solicitudes
app.use((req, res, next) => {
    console.log(`Solicitud recibida: ${req.method} ${req.url}`);
    next(); // Continúa con la siguiente función
});

// Importamos las rutas después de inicializar Express
const rutas = require('./routes/rutas');
app.use(rutas);

// Definimos el puerto
const PORT = 3000;

// Iniciamos el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
